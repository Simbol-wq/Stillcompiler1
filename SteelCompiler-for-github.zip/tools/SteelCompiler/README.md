# SteelCompiler v0.1 (первая рабочая версия)

Десктопный GUI-инструмент для сборки Minecraft-модов на Gradle. Написан на чистой Java (Swing) —
для запуска нужен только JDK, никакого дополнительного рантайма.

## Что уже работает в этой версии

- Выбор корневой папки проекта мода (там, где лежит `gradlew` / `gradlew.bat`).
- Поле для Gradle-задачи (по умолчанию `build`, можно ввести `build --stacktrace`, `clean build` и т.д.).
- Кнопка **«Собрать»** — запускает `gradlew <задача>` в отдельном потоке, не блокируя интерфейс.
- Окно логов сборки в реальном времени (stdout и stderr объединены в один поток).
- Кнопка **«Отмена»** — принудительно останавливает текущую сборку.
- После успешной сборки — автопоиск получившихся `.jar` во всех папках `build/libs` проекта
  (включая подмодули) и кнопка «Открыть папку с .jar».
- Запоминание последней выбранной папки проекта и последней Gradle-задачи между запусками
  (через `java.util.prefs.Preferences`, ничего никуда не отправляется).

## Как собрать и запустить

### Вариант A — просто через javac/java (без Gradle, самый быстрый способ проверить)

Из корня папки `SteelCompiler`:

```bash
mkdir -p out
javac -d out $(find src/main/java -name "*.java")
java -cp out com.steelcompiler.Main
```

На Windows (PowerShell) вместо `find` собери список файлов вручную или через:

```powershell
mkdir out
Get-ChildItem -Recurse -Filter *.java src\main\java | ForEach-Object { $_.FullName } | Out-File sources.txt
javac -d out "@sources.txt"
java -cp out com.steelcompiler.Main
```

### Вариант B — через Gradle (если хочешь runnable .jar)

Если у тебя уже установлен Gradle (он тебе всё равно нужен для сборки самого мода):

```bash
gradle wrapper          # один раз, сгенерирует gradlew/gradlew.bat для этого проекта
./gradlew steelCompilerJar
java -jar build/libs/SteelCompiler-0.1.0.jar
```

Либо сразу через `application`-плагин:

```bash
gradle run
```

## Куда добавлять в твой репозиторий

Эти файлы — самостоятельный инструмент, не часть самого мода. Рекомендую положить их
в отдельную папку внутри репозитория `Simbol-wq/Stillandcrowns`, например `tools/SteelCompiler/`,
чтобы не путать с исходниками мода в `com.steelandcrowns`. Структура:

```
tools/
  SteelCompiler/
    build.gradle
    settings.gradle
    src/main/java/com/steelcompiler/
      Main.java
      MainWindow.java
      GradleBuildRunner.java
      JarFinder.java
    README.md
```

Так `.github/workflows/main.yml`, который уже собирает основной мод через `./gradlew build`,
трогать не нужно — SteelCompiler живёт рядом и не мешает существующей сборке.

## Что дальше (следующие шаги по твоему плану)

Помечено `TODO` прямо в `MainWindow.java`:

1. Дерево файлов проекта (`JTree`) слева + простой текстовый редактор справа.
2. Подсветка строк с ошибками в логе (`FAILED`, `error:`, `Exception`) — потребует
   заменить `JTextArea` на `JTextPane`/`StyledDocument`, чтобы красить отдельные строки.
3. Автовыбор версии Java под версию Minecraft (парсинг `gradle.properties`) и переключение
   `JAVA_HOME` для процесса сборки.
4. Вкладка «GitHub Actions» — запуск существующего workflow через GitHub REST API
   (`POST /repos/{owner}/{repo}/actions/workflows/{id}/dispatches`), понадобится
   Personal Access Token с правом `actions:write`.
5. Отдельный «профиль steelandcrowns» с закреплённым путём к проекту и быстрыми кнопками
   для частых задач (`build`, `runClient`, `runServer`).

Скажи, какой из этих пунктов брать следующим — соберу его так же, полностью рабочим кодом.
